package res;

public abstract class CrewMember implements Mobility, Speach, Naming {

}
