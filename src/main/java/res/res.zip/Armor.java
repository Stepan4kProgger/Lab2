package res;

public interface Armor {
    abstract int reduceTakenDamage(int takenDamage, int armor);
}
