package res;

public interface Mobility extends Weapon {
    abstract int move(int speed, int distance);
}
