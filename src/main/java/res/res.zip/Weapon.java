package res;

public interface Weapon {
    abstract int dealDamage(int armor, int penetration);
}
