package res;

public interface Speach extends Weapon{
    String say(String text);
}
