package res;

public interface Naming {
    abstract void setName(String name);
}
